#!/bin/bash

# ===========================================
# Scheduled Maintenance Script
# Runs log rotation + backup, logs everything
# ===========================================

set -euo pipefail

# ---- Configuration ----
SCRIPT_DIR="/root/2026/day-19"
LOG_DIR="/root/test-logs"
SOURCE_DIR="/root/test-source"
BACKUP_DIR="/root/test-backups"
MAINT_LOG="/var/log/maintenance.log"

# ---- Helper: log a message with a timestamp ----
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') | $1" | tee -a "$MAINT_LOG"
}

# ---- Make sure the maintenance log exists and is writable ----
touch "$MAINT_LOG"

log "===== Maintenance Run Started ====="

# ---- Run Log Rotation ----
log "--- Running log rotation ---"
if "$SCRIPT_DIR/log_rotate.sh" "$LOG_DIR" >> "$MAINT_LOG" 2>&1; then
    log "Log rotation: SUCCESS"
else
    log "Log rotation: FAILED"
fi

# ---- Run Backup ----
log "--- Running backup ---"
if "$SCRIPT_DIR/backup.sh" "$SOURCE_DIR" "$BACKUP_DIR" >> "$MAINT_LOG" 2>&1; then
    log "Backup: SUCCESS"
else
    log "Backup: FAILED"
fi

log "===== Maintenance Run Complete ====="
echo

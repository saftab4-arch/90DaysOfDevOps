#!/bin/bash

# ===========================================
# Server Backup Script
# Usage: ./backup.sh <source_dir> <destination_dir>
# ===========================================

set -euo pipefail

# ---- Step 1: Check we got both arguments ----
if [ $# -ne 2 ]; then
    echo "Usage: $0 <source_directory> <destination_directory>"
    exit 1
fi

SOURCE_DIR="$1"
DEST_DIR="$2"

# ---- Step 2: Verify source exists ----
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Error: Source directory '$SOURCE_DIR' does not exist"
    exit 1
fi

# ---- Step 3: Make sure destination exists (create if not) ----
mkdir -p "$DEST_DIR"

# ---- Step 4: Build a timestamped archive filename ----
TIMESTAMP=$(date +%Y-%m-%d)
ARCHIVE_NAME="backup-${TIMESTAMP}.tar.gz"
ARCHIVE_PATH="${DEST_DIR}/${ARCHIVE_NAME}"

echo "===== Backup Starting ====="
echo "Source:      $SOURCE_DIR"
echo "Destination: $DEST_DIR"
echo "Archive:     $ARCHIVE_NAME"
echo

# ---- Step 5: Create the archive ----
echo "Creating archive..."
tar -czf "$ARCHIVE_PATH" -C "$(dirname "$SOURCE_DIR")" "$(basename "$SOURCE_DIR")"

# ---- Step 6: Verify the archive was created ----
if [ ! -f "$ARCHIVE_PATH" ]; then
    echo "Error: Archive was not created"
    exit 1
fi

ARCHIVE_SIZE=$(du -h "$ARCHIVE_PATH" | cut -f1)
echo "Archive created successfully"
echo "Name: $ARCHIVE_NAME"
echo "Size: $ARCHIVE_SIZE"
echo

# ---- Step 7: Delete backups older than 14 days ----
echo "Cleaning up old backups (older than 14 days)..."
old_count=$(find "$DEST_DIR" -type f -name "backup-*.tar.gz" -mtime +14 | wc -l)
find "$DEST_DIR" -type f -name "backup-*.tar.gz" -mtime +14 -exec rm -f {} \;
echo "Deleted: $old_count old backup(s)"
echo

echo "===== Backup Complete ====="

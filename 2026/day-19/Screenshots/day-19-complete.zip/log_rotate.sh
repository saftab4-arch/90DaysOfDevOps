#!/bin/bash

# ===========================================
# Log Rotation Script
# Usage: ./log_rotate.sh /path/to/log/dir
# ===========================================

set -euo pipefail

# ---- Step 1: Check we got an argument ----
if [ -z "${1:-}" ]; then
    echo "Usage: $0 <log_directory>"
    exit 1
fi

LOG_DIR="$1"

# ---- Step 2: Check the directory actually exists ----
if [ ! -d "$LOG_DIR" ]; then
    echo "Error: Directory '$LOG_DIR' does not exist"
    exit 1
fi

echo "===== Log Rotation Starting ====="
echo "Target directory: $LOG_DIR"
echo

# ---- Step 3: Compress .log files older than 7 days ----
echo "Compressing .log files older than 7 days..."

compressed_count=$(find "$LOG_DIR" -type f -name "*.log" -mtime +7 | wc -l)

find "$LOG_DIR" -type f -name "*.log" -mtime +7 -exec gzip {} \;

echo "Compressed: $compressed_count file(s)"
echo

# ---- Step 4: Delete .gz files older than 30 days ----
echo "Deleting .gz files older than 30 days..."

deleted_count=$(find "$LOG_DIR" -type f -name "*.gz" -mtime +30 | wc -l)

find "$LOG_DIR" -type f -name "*.gz" -mtime +30 -exec rm -f {} \;

echo "Deleted: $deleted_count file(s)"
echo

echo "===== Log Rotation Complete ====="
